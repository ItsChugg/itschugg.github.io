@echo off
cd /d "%~dp0"
echo =========================================
echo  RIZK - Starting local server...
echo =========================================
echo.

:: Open browser after 2 seconds
start /b cmd /c "timeout /t 2 >nul && start http://localhost:8080"

:: Try Node.js (npx serve)
where npx >nul 2>&1
if not errorlevel 1 (
    npx --yes serve . --listen 8080 --no-clipboard
    goto :eof
)

:: Try Python
python --version >nul 2>&1
if not errorlevel 1 (
    python -m http.server 8080
    goto :eof
)

python3 --version >nul 2>&1
if not errorlevel 1 (
    python3 -m http.server 8080
    goto :eof
)

:: Fall back to built-in PowerShell HTTP server (no installs needed)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1" -WebRoot "%~dp0" -Port 8080

pause
