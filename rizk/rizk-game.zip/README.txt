RIZK - Science Museum Flash Game
=================================
A preserved copy of the lost Flash game originally hosted at sciencemuseum.org.uk.
Playable via Ruffle (an open-source Flash emulator).

REQUIREMENTS
------------
- Python 3 (https://www.python.org/downloads/) — used to run a local web server
- A modern browser (Chrome, Firefox, Edge)

HOW TO PLAY
-----------
1. Double-click start.bat
2. Open your browser and go to:  http://localhost:8080
3. The game will load automatically.
4. When done, go back to the terminal window and press Ctrl+C to stop.

WHY A SERVER?
-------------
Flash games load external files (level data, assets) via HTTP.
Browsers block this when running from a local file path, so a tiny
local web server is needed. start.bat handles this automatically.

FOLDER STRUCTURE
----------------
  index.html       - Game page (loads Ruffle + SMGame.swf)
  SMGame.swf       - Main game SWF
  ruffle/
    ruffle.js      - Ruffle Flash emulator
  assets/
    levels/        - Level SWF files (level01.swf - level15.swf)
    xml/           - Level and game config XML files
  start.bat        - Launches local server (Windows)
  README.txt       - This file
