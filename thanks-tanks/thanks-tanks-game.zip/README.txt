THANKS TANKS! - Isaac Williams Flash Game
==========================================
A preserved copy of the Flash game by Isaac Williams, with music by Robert D. Jordan (2010).
Playable via Ruffle (an open-source Flash emulator).

REQUIREMENTS
------------
- Nothing extra on Windows. start.bat uses Node.js or Python 3 if you have
  them, and otherwise falls back to PowerShell, which is built in.
- A modern browser (Chrome, Firefox, Edge)

HOW TO PLAY
-----------
1. Double-click start.bat
2. Open your browser and go to:  http://localhost:8080
3. The game will load automatically.
4. When done, go back to the terminal window and press Ctrl+C to stop.

WHY A SERVER?
-------------
Ruffle loads its emulator files and the game over HTTP.
Browsers block this when running from a local file path, so a tiny
local web server is needed. start.bat handles this automatically.

FOLDER STRUCTURE
----------------
  index.html       - Game page (loads Ruffle + thanks-tanks.swf)
  thanks-tanks.swf - Main game SWF
  ruffle/
    ruffle.js      - Ruffle Flash emulator
  start.bat        - Launches local server (Windows)
  server.ps1       - Fallback local server (no installs needed)
  README.txt       - This file
